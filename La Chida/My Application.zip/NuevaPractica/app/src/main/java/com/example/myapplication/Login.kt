package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login : AppCompatActivity() {

    private var intentos = 0
    private val maxIntentos = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        val usuario = findViewById<EditText>(R.id.txtUsuario)
        val contrasena = findViewById<EditText>(R.id.txtContrasena)
        val ingresar = findViewById<Button>(R.id.btnIngresar)

        ingresar.setOnClickListener {
            val user = usuario.text.toString().trim()
            val password = contrasena.text.toString()

            if (user == "admin" && password == "1234") {
                startActivity(Intent(this, Operaciones::class.java))
                finish()
            } else {
                intentos++

                if (intentos < maxIntentos) {
                    val restantes = maxIntentos - intentos
                    Toast.makeText(this, "Usuario o contraseña incorrectos. Te quedan $restantes intento(s)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this,"Has agotado tus 3 intentos. Acceso bloqueado", Toast.LENGTH_LONG).show()
                }
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}