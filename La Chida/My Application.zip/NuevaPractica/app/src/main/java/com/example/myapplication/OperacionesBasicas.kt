package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class OperacionesBasicas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_operacionesb)

        val valor1 = findViewById<EditText>(R.id.txtValor1)
        val valor2 = findViewById<EditText>(R.id.txtValor2)
        val suma = findViewById<RadioButton>(R.id.rbSuma)
        val resta = findViewById<RadioButton>(R.id.rbResta)
        val multiplicacion = findViewById<RadioButton>(R.id.rbMultiplicacion)
        val division = findViewById<RadioButton>(R.id.rbDivision)
        val resultado = findViewById<TextView>(R.id.txtResultado)

        findViewById<Button>(R.id.btnCalcular).setOnClickListener {
            val a = valor1.text.toString().toDoubleOrNull()
            val b = valor2.text.toString().toDoubleOrNull()

            if (a == null || b == null) {
                Toast.makeText(this, "Ingresa los dos valores", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val res = when {
                suma.isChecked -> a + b
                resta.isChecked -> a - b
                multiplicacion.isChecked -> a * b
                division.isChecked -> {
                    if (b == 0.0) {
                        Toast.makeText(this, "No se puede dividir entre cero", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    a / b
                }
                else -> {
                    Toast.makeText(this, "Selecciona una operación", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            resultado.text = formatear(res)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun formatear(valor: Double): String {
        return if (valor % 1.0 == 0.0) valor.toLong().toString() else "%.2f".format(valor)
    }
}
