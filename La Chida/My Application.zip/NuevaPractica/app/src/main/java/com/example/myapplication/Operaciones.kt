package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Operaciones : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_operaciones)

        findViewById<Button>(R.id.btnOperacionesBasicas).setOnClickListener {
            startActivity(Intent(this, OperacionesBasicas::class.java))
        }

        findViewById<Button>(R.id.btnAreas).setOnClickListener {
            startActivity(Intent(this, Areas::class.java))
        }

        findViewById<Button>(R.id.btnPerimetro).setOnClickListener {
            startActivity(Intent(this, Perimetro::class.java))
        }

        findViewById<Button>(R.id.btnDatosPersonales).setOnClickListener {
            startActivity(Intent(this, DatosPersonales::class.java))
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
