package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DatosPersonales : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.datos_personales)

        val nombre = findViewById<EditText>(R.id.editNombre)
        val direccion = findViewById<EditText>(R.id.editDireccion)
        val telefono = findViewById<EditText>(R.id.editTelefono)
        val correo = findViewById<EditText>(R.id.editCorreo)
        val masculino = findViewById<RadioButton>(R.id.rbMasculino)
        val femenino = findViewById<RadioButton>(R.id.rbFemenino)
        val nacimiento = findViewById<EditText>(R.id.editNacimiento)
        val guardar = findViewById<Button>(R.id.btnGuardarDatos)

        guardar.setOnClickListener {
            if (nombre.text.toString().trim().isEmpty() ||
                direccion.text.toString().trim().isEmpty() ||
                telefono.text.toString().trim().isEmpty() ||
                correo.text.toString().trim().isEmpty() ||
                (!masculino.isChecked && !femenino.isChecked) ||
                nacimiento.text.toString().trim().isEmpty()
            ) {
                Toast.makeText(this, "Completa todos los datos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Datos personales guardados", Toast.LENGTH_SHORT).show()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
