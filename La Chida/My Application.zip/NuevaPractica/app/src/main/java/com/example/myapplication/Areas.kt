package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.PI

class Areas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_areas)

        val base = findViewById<EditText>(R.id.txtBase)
        val altura = findViewById<EditText>(R.id.txtAltura)
        val cuadrado = findViewById<RadioButton>(R.id.rbCuadrado)
        val triangulo = findViewById<RadioButton>(R.id.rbTriangulo)
        val rectangulo = findViewById<RadioButton>(R.id.rbRectangulo)
        val circulo = findViewById<RadioButton>(R.id.rbCirculo)
        val resultado = findViewById<TextView>(R.id.txtResultadoArea)
        val imgFigura = findViewById<ImageView>(R.id.imgFigura)

        findViewById<android.widget.RadioGroup>(R.id.grupoFiguras).setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbCuadrado -> {
                    imgFigura.setImageResource(R.drawable.cuadrado)
                }
                R.id.rbTriangulo -> {
                    imgFigura.setImageResource(R.drawable.triangulo)
                }
                R.id.rbRectangulo -> {
                    imgFigura.setImageResource(R.drawable.rectangulo)
                }
                R.id.rbCirculo -> {
                    imgFigura.setImageResource(R.drawable.circulo)
                }
            }
        }

        findViewById<Button>(R.id.btnCalcularArea).setOnClickListener {
            val b = base.text.toString().toDoubleOrNull()
            val h = altura.text.toString().toDoubleOrNull()

            if (b == null) {
                Toast.makeText(this, "Ingresa la base o el radio", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val area = when {
                cuadrado.isChecked -> b * b
                triangulo.isChecked -> {
                    if (h == null) {
                        Toast.makeText(this, "Ingresa la altura", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    (b * h) / 2
                }
                rectangulo.isChecked -> {
                    if (h == null) {
                        Toast.makeText(this, "Ingresa la altura", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    b * h
                }
                circulo.isChecked -> PI * b * b
                else -> {
                    Toast.makeText(this, "Selecciona una figura", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            resultado.text = formatear(area)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun formatear(valor: Double): String {
        return if (valor % 1.0 == 0.0) valor.toLong().toString() else "%.2f".format(valor)
    }
}
