package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Perimetro : AppCompatActivity() {

    private lateinit var lados: List<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.perimetro)

        val spinner = findViewById<Spinner>(R.id.spinner)
        val resultado = findViewById<TextView>(R.id.textView5)
        val calcular = findViewById<Button>(R.id.button3)

        lados = listOf(
            findViewById(R.id.editLado1),
            findViewById(R.id.editLado2),
            findViewById(R.id.editLado3),
            findViewById(R.id.editLado4),
            findViewById(R.id.editLado5),
            findViewById(R.id.editLado6)
        )

        val opciones = arrayOf("1", "2", "3", "4", "5", "6")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opciones)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: android.widget.AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val cantidad = position + 1

                for (i in lados.indices) {
                    lados[i].isEnabled = i < cantidad
                    if (i >= cantidad) {
                        lados[i].text.clear()
                    }
                }

                resultado.text = ""
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {
            }
        }

        calcular.setOnClickListener {
            val cantidad = spinner.selectedItemPosition + 1
            var perimetro = 0.0

            for (i in 0 until cantidad) {
                val valor = lados[i].text.toString().toDoubleOrNull()

                if (valor == null || valor <= 0) {
                    lados[i].requestFocus()
                    Toast.makeText(
                        this,
                        "Ingresa una medida válida para el lado ${i + 1}",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }

                perimetro += valor
            }

            resultado.text = formatear(perimetro)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun formatear(valor: Double): String {
        return if (valor % 1.0 == 0.0) {
            valor.toLong().toString()
        } else {
            "%.2f".format(valor)
        }
    }
}
