PRACTICA ANDROID STUDIO - OPERACIONES

Basada en la estructura de la practica Osix/MyApplication2: Kotlin + XML + ConstraintLayout + AppCompat.

ACCESO
Usuario: admin
Contraseña: 1234

FLUJO
1. Login -> Ingresar -> Operaciones.
2. Operaciones Basicas -> pantalla de operaciones.
3. Areas -> pantalla de areas.

OPERACIONES BASICAS
- Suma
- Resta
- Multiplicacion
- Division (valida division entre cero)

AREAS
- Cuadro: lado x lado (se usa Base como lado).
- Triangulo: base x altura / 2.
- Rectangulo: base x altura.
- Circulo: pi x radio x radio (se usa Base como radio).

Los RadioButton seleccionan una sola operacion o figura a la vez y el boton Calcular muestra el resultado.
